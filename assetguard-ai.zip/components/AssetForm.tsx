import React, { useState, useEffect, useRef } from 'react';
import { Asset, Settings } from '../types';
import { dbService } from '../services/db';
import { geminiService } from '../services/geminiService';
import { ArrowLeft, Camera, Sparkles, X, Save, MapPin, Tag, Hash, FileText, ChevronDown } from 'lucide-react';

interface AssetFormProps {
  categoryId: string;
  existingAsset?: Asset;
  onClose: () => void;
  onSave: () => void;
  onViewImage: (images: string[], index: number) => void;
}

export const AssetForm: React.FC<AssetFormProps> = ({ categoryId, existingAsset, onClose, onSave, onViewImage }) => {
  const [formData, setFormData] = useState<Partial<Asset>>({
    categoryId,
    photos: [],
    name: '',
    serialNumber: '',
    assetId: '',
    location: '',
    note: ''
  });
  const [settings, setSettings] = useState<Settings | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadSettings();
    if (existingAsset) {
      setFormData(existingAsset);
    } else {
      initializeNewAsset();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadSettings = async () => {
    const s = await dbService.getSettings();
    setSettings(s);
  };

  const initializeNewAsset = async () => {
    const s = await dbService.getSettings();
    if (s && s.lastUsedPrefix) {
       // Simple auto-increment suggestion logic
       const nextSeq = (s.lastUsedSequence || 0) + 1;
       const nextId = `${s.lastUsedPrefix}${nextSeq.toString().padStart(4, '0')}`;
       setFormData(prev => ({ ...prev, assetId: nextId }));
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        // Resize image to prevent massive DB growth
        resizeImage(base64String, 800, 0.8, (resizedImage) => {
           setFormData(prev => ({
            ...prev,
            photos: [...(prev.photos || []), resizedImage].slice(0, 3) // Max 3
          }));
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const resizeImage = (base64: string, maxWidth: number, quality: number, callback: (resized: string) => void) => {
    const img = new Image();
    img.src = base64;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > maxWidth) {
        height = Math.round((height * maxWidth) / width);
        width = maxWidth;
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);
      callback(canvas.toDataURL('image/jpeg', quality));
    };
  };

  const analyzeLatestImage = async () => {
    const photos = formData.photos;
    if (!photos || photos.length === 0) {
      alert("請先上傳照片");
      return;
    }
    
    setIsAnalyzing(true);
    try {
      const result = await geminiService.analyzeAssetImage(photos[photos.length - 1]);
      setFormData(prev => ({
        ...prev,
        name: result.name || prev.name,
        serialNumber: result.serialNumber || prev.serialNumber,
        assetId: result.assetId || prev.assetId,
        location: result.location || prev.location
      }));
    } catch (e) {
      alert("AI 分析失敗，請稍後再試");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSave = async () => {
    if (!formData.name) {
      alert("請輸入資產名稱");
      return;
    }

    const assetToSave: Asset = {
      id: existingAsset?.id || crypto.randomUUID(),
      categoryId: formData.categoryId!,
      name: formData.name!,
      serialNumber: formData.serialNumber || '',
      assetId: formData.assetId || '',
      location: formData.location || '',
      note: formData.note || '',
      photos: formData.photos || [],
      createdAt: existingAsset?.createdAt || Date.now(),
      updatedAt: Date.now()
    };

    await dbService.saveAsset(assetToSave);

    // Update settings: if user manually typed a prefix, we could save it,
    // but here we simply update 'lastUsed' if needed in a more complex app.
    
    onSave();
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <div className="bg-white border-b px-4 py-3 flex items-center justify-between shadow-sm sticky top-0 z-20">
        <div className="flex items-center">
          <button onClick={onClose} className="p-2 mr-2 -ml-2 rounded-full hover:bg-gray-100">
            <ArrowLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">{existingAsset ? '編輯資產' : '新增資產'}</h1>
        </div>
        <button 
          onClick={handleSave}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium flex items-center shadow-sm active:scale-95 transition-transform"
        >
          <Save className="w-4 h-4 mr-2" />
          儲存
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6 pb-20">
        
        {/* Photos Section */}
        <div className="space-y-3">
          <label className="block text-sm font-semibold text-gray-700">照片 (最多 3 張，點擊可放大)</label>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {formData.photos?.map((photo, idx) => (
              <div key={idx} className="relative flex-shrink-0 w-24 h-24 rounded-lg overflow-hidden border border-gray-200 shadow-sm group">
                <img 
                  src={photo} 
                  alt="Asset" 
                  className="w-full h-full object-cover cursor-zoom-in" 
                  onClick={() => onViewImage(formData.photos || [], idx)}
                />
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setFormData(p => ({ ...p, photos: p.photos?.filter((_, i) => i !== idx) }));
                  }}
                  className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-1"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
            
            {(formData.photos?.length || 0) < 3 && (
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="w-24 h-24 flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg text-gray-400 hover:border-blue-500 hover:text-blue-500 bg-gray-50 flex-shrink-0"
              >
                <Camera className="w-8 h-8 mb-1" />
                <span className="text-xs">拍照/上傳</span>
              </button>
            )}
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              capture="environment"
              onChange={handleImageUpload} 
            />
          </div>

          {/* AI Analysis Button */}
          {formData.photos && formData.photos.length > 0 && (
            <button
              onClick={analyzeLatestImage}
              disabled={isAnalyzing}
              className={`w-full py-3 rounded-lg flex items-center justify-center font-medium transition-colors ${
                isAnalyzing 
                  ? 'bg-purple-100 text-purple-400 cursor-wait' 
                  : 'bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200'
              }`}
            >
              {isAnalyzing ? (
                <span>AI 分析中...</span>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  使用 Gemini AI 自動辨識
                </>
              )}
            </button>
          )}
        </div>

        {/* Basic Info */}
        <div className="space-y-4">
          <div className="relative">
             <label className="block text-sm font-semibold text-gray-700 mb-1 flex items-center">
                <Tag className="w-4 h-4 mr-1 text-gray-400" /> 資產名稱
             </label>
             <input
               list="names-list"
               type="text"
               value={formData.name}
               onChange={(e) => setFormData(p => ({ ...p, name: e.target.value }))}
               className="w-full border rounded-lg px-4 py-3 text-lg focus:ring-2 focus:ring-blue-500 outline-none"
               placeholder="例如：MacBook Pro"
             />
             <datalist id="names-list">
               {settings?.savedNames.map((n, i) => <option key={i} value={n} />)}
             </datalist>
          </div>

          <div className="grid grid-cols-2 gap-4">
             <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1 flex items-center">
                  <Hash className="w-4 h-4 mr-1 text-gray-400" /> 資產編號
                </label>
                <div className="relative">
                  <input
                    list="prefix-list"
                    type="text"
                    value={formData.assetId}
                    onChange={(e) => setFormData(p => ({ ...p, assetId: e.target.value }))}
                    className="w-full border rounded-lg pl-3 pr-8 py-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="0700-0253"
                  />
                  <ChevronDown className="absolute right-3 top-3.5 w-4 h-4 text-gray-400 pointer-events-none" />
                </div>
                <datalist id="prefix-list">
                   {settings?.savedPrefixes.map((p, i) => <option key={i} value={p} />)}
                </datalist>
             </div>
             <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1">序列號 (S/N)</label>
                <input
                  type="text"
                  value={formData.serialNumber}
                  onChange={(e) => setFormData(p => ({ ...p, serialNumber: e.target.value }))}
                  className="w-full border rounded-lg px-3 py-3 focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
                  placeholder="X1Y2Z3..."
                />
             </div>
          </div>

          <div>
             <label className="block text-sm font-semibold text-gray-700 mb-1 flex items-center">
                <MapPin className="w-4 h-4 mr-1 text-gray-400" /> 資產地點
             </label>
             <input
               list="locations-list"
               type="text"
               value={formData.location}
               onChange={(e) => setFormData(p => ({ ...p, location: e.target.value }))}
               className="w-full border rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none"
               placeholder="例如：會議室 A"
             />
             <datalist id="locations-list">
               {settings?.savedLocations.map((l, i) => <option key={i} value={l} />)}
             </datalist>
          </div>

           <div>
             <label className="block text-sm font-semibold text-gray-700 mb-1 flex items-center">
                <FileText className="w-4 h-4 mr-1 text-gray-400" /> 備註 (移動需求)
             </label>
             <textarea
               value={formData.note}
               onChange={(e) => setFormData(p => ({ ...p, note: e.target.value }))}
               className="w-full border rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none h-24 resize-none"
               placeholder="若資產需要移動，請填寫目標地點..."
             />
          </div>
        </div>

      </div>
    </div>
  );
};