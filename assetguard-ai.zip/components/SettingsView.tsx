import React, { useState, useEffect } from 'react';
import { Settings } from '../types';
import { dbService } from '../services/db';
import { Trash2, Plus, Save, ArrowLeft } from 'lucide-react';

interface SettingsViewProps {
  onBack: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onBack }) => {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [activeTab, setActiveTab] = useState<'names' | 'locations' | 'prefixes'>('names');
  const [newItem, setNewItem] = useState('');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    const s = await dbService.getSettings();
    setSettings(s);
  };

  const handleAddItem = async () => {
    if (!newItem.trim() || !settings) return;
    const updated = { ...settings };
    
    if (activeTab === 'names') updated.savedNames.push(newItem.trim());
    if (activeTab === 'locations') updated.savedLocations.push(newItem.trim());
    if (activeTab === 'prefixes') updated.savedPrefixes.push(newItem.trim());

    await dbService.saveSettings(updated);
    setSettings(updated);
    setNewItem('');
  };

  const handleDeleteItem = async (index: number) => {
    if (!settings) return;
    const updated = { ...settings };

    if (activeTab === 'names') updated.savedNames.splice(index, 1);
    if (activeTab === 'locations') updated.savedLocations.splice(index, 1);
    if (activeTab === 'prefixes') updated.savedPrefixes.splice(index, 1);

    await dbService.saveSettings(updated);
    setSettings(updated);
  };

  if (!settings) return <div className="p-8 text-center text-gray-500">載入中...</div>;

  const getList = () => {
    if (activeTab === 'names') return settings.savedNames;
    if (activeTab === 'locations') return settings.savedLocations;
    return settings.savedPrefixes;
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <div className="bg-white border-b px-4 py-3 flex items-center shadow-sm sticky top-0 z-10">
        <button onClick={onBack} className="p-2 mr-2 rounded-full hover:bg-gray-100">
          <ArrowLeft className="w-6 h-6 text-gray-700" />
        </button>
        <h1 className="text-xl font-bold text-gray-800">資料庫設定</h1>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200">
        <button
          onClick={() => setActiveTab('names')}
          className={`flex-1 py-3 text-sm font-medium ${activeTab === 'names' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
        >
          資產名稱
        </button>
        <button
          onClick={() => setActiveTab('locations')}
          className={`flex-1 py-3 text-sm font-medium ${activeTab === 'locations' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
        >
          地點清單
        </button>
        <button
          onClick={() => setActiveTab('prefixes')}
          className={`flex-1 py-3 text-sm font-medium ${activeTab === 'prefixes' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
        >
          編號規則
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            value={newItem}
            onChange={(e) => setNewItem(e.target.value)}
            placeholder={`新增${activeTab === 'names' ? '名稱' : activeTab === 'locations' ? '地點' : '前綴'}...`}
            className="flex-1 border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
            onKeyDown={(e) => e.key === 'Enter' && handleAddItem()}
          />
          <button
            onClick={handleAddItem}
            className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2">
          {getList().map((item, index) => (
            <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg border">
              <span className="text-gray-800">{item}</span>
              <button
                onClick={() => handleDeleteItem(index)}
                className="text-red-500 p-2 hover:bg-red-50 rounded-full"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
          {getList().length === 0 && (
            <div className="text-center text-gray-400 py-8">
              暫無資料，請新增常用項目以加速盤點。
            </div>
          )}
        </div>
      </div>
    </div>
  );
};