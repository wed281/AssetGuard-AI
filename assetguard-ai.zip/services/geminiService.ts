import { GoogleGenAI, Type } from "@google/genai";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async analyzeAssetImage(base64Image: string): Promise<{
    name?: string;
    serialNumber?: string;
    assetId?: string;
    location?: string;
  }> {
    try {
      // Remove header if present (e.g. data:image/jpeg;base64,)
      const data = base64Image.split(',')[1] || base64Image;

      const response = await this.ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: 'image/jpeg',
                data: data
              }
            },
            {
              text: `Analyze this image of an asset. 
              Extract the following details if visible:
              1. Asset Name (what is the item?)
              2. Serial Number (S/N, SN, No.)
              3. Asset Tag ID (labels with barcodes or property ID)
              4. A generic location description if relevant (e.g. 'Server Room', 'Office Desk').
              
              Return the result in JSON format.`
            }
          ]
        },
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              serialNumber: { type: Type.STRING },
              assetId: { type: Type.STRING },
              location: { type: Type.STRING },
            }
          }
        }
      });

      if (response.text) {
        return JSON.parse(response.text);
      }
      return {};
    } catch (error) {
      console.error("Gemini Analysis Failed:", error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();