import { Asset, Category, Settings } from '../types';

const DB_NAME = 'AssetGuardDB';
const DB_VERSION = 1;

export class DBService {
  private db: IDBDatabase | null = null;

  async connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => reject('Database error');
      request.onsuccess = (event) => {
        this.db = (event.target as IDBOpenDBRequest).result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        if (!db.objectStoreNames.contains('assets')) {
          const assetStore = db.createObjectStore('assets', { keyPath: 'id' });
          assetStore.createIndex('categoryId', 'categoryId', { unique: false });
        }
        
        if (!db.objectStoreNames.contains('categories')) {
          db.createObjectStore('categories', { keyPath: 'id' });
        }

        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'id' });
        }
      };
    });
  }

  // --- Assets ---

  async getAssetsByCategory(categoryId: string): Promise<Asset[]> {
    return new Promise((resolve) => {
      if (!this.db) return resolve([]);
      const transaction = this.db.transaction(['assets'], 'readonly');
      const store = transaction.objectStore('assets');
      const index = store.index('categoryId');
      const request = index.getAll(categoryId);
      
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve([]);
    });
  }

  async getAllAssets(): Promise<Asset[]> {
    return new Promise((resolve) => {
      if (!this.db) return resolve([]);
      const transaction = this.db.transaction(['assets'], 'readonly');
      const store = transaction.objectStore('assets');
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve([]);
    });
  }

  async saveAsset(asset: Asset): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.db) return reject('DB not initialized');
      const transaction = this.db.transaction(['assets'], 'readwrite');
      const store = transaction.objectStore('assets');
      const request = store.put(asset);
      request.onsuccess = () => resolve();
      request.onerror = () => reject('Save failed');
    });
  }

  async deleteAsset(id: string): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.db) return reject('DB not initialized');
      const transaction = this.db.transaction(['assets'], 'readwrite');
      const store = transaction.objectStore('assets');
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject('Delete failed');
    });
  }

  // --- Categories ---

  async getAllCategories(): Promise<Category[]> {
    return new Promise((resolve) => {
      if (!this.db) return resolve([]);
      const transaction = this.db.transaction(['categories'], 'readonly');
      const store = transaction.objectStore('categories');
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve([]);
    });
  }

  async saveCategory(category: Category): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.db) return reject('DB not initialized');
      const transaction = this.db.transaction(['categories'], 'readwrite');
      const store = transaction.objectStore('categories');
      const request = store.put(category);
      request.onsuccess = () => resolve();
      request.onerror = () => reject('Save failed');
    });
  }

  async deleteCategory(id: string): Promise<void> {
     return new Promise((resolve, reject) => {
      if (!this.db) return reject('DB not initialized');
      const transaction = this.db.transaction(['categories'], 'readwrite');
      const store = transaction.objectStore('categories');
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject('Delete failed');
    });
  }

  // --- Settings ---

  async getSettings(): Promise<Settings> {
    return new Promise((resolve) => {
      if (!this.db) return resolve(this.getDefaultSettings());
      const transaction = this.db.transaction(['settings'], 'readonly');
      const store = transaction.objectStore('settings');
      const request = store.get('global');
      
      request.onsuccess = () => {
        resolve(request.result || this.getDefaultSettings());
      };
      request.onerror = () => resolve(this.getDefaultSettings());
    });
  }

  async saveSettings(settings: Settings): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.db) return reject('DB not initialized');
      const transaction = this.db.transaction(['settings'], 'readwrite');
      const store = transaction.objectStore('settings');
      const request = store.put({ ...settings, id: 'global' });
      request.onsuccess = () => resolve();
      request.onerror = () => reject('Save failed');
    });
  }

  private getDefaultSettings(): Settings {
    return {
      savedNames: ['筆記型電腦', '顯示器', '辦公桌', '人體工學椅'],
      savedLocations: ['會議室 A', '會議室 B', '庫房', '主要辦公區'],
      savedPrefixes: ['ASSET-', 'IT-', 'OFFICE-'],
      lastUsedPrefix: '',
      lastUsedSequence: 1,
    };
  }
}

export const dbService = new DBService();